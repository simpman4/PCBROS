INSERT INTO IOTBAYUSER.CUSTOMERS (EMAIL, PASSWORD, FULLNAME, STREET, SUBURB, STATE, POSTCODE, DOB, PHONENUM)
VALUES
    ('1@gmail.com', 'pass1', 'Bob Bob', '21 Laurel place', 'Liverpool', 'NSW', '2000', '1020-02-01','0416122357'),
    ('2@yahoo.com', 'pass', 'Tim Tim', '22 Laurel place', 'Sydney', 'QLD', '0001','1300-02-01','0412345678'),
    ('3@gmail.com', 'wordpass123', 'Jan Smith', '23 Laurel place', 'Sydney', 'QLD','1000','2000-02-01', '0457162318');

