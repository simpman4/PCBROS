/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Joshua
 * Created: 7 Jun 2020
 */

INSERT INTO IOTBAYUSER.PAYMENT(CARDNUMBER, PAYMENTMETHOD, CVC, EXPIRYDATE)
VALUES
('1234567812345678', 'Mastercard', '123', '2020-06-08'),
('4532155653421236', 'Visa', '643', '2022-03-05'),
('5646845313125712', 'Other', '842', '2027-08-23')
