/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Ethan
 * Created: Jun 7, 2020
 */

CREATE TABLE PRODUCTS (
    PRODUCTNAME VARCHAR(50) PRIMARY KEY, DEVICETYPE VARCHAR(50), UNITPRICE VARCHAR(10), QUANTITY VARCHAR(50)
);

