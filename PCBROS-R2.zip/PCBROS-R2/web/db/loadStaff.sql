INSERT INTO IOTBAYUSER.STAFF (EMAIL, PASSWORD, FULLNAME, POSITION, PHONENUM)
VALUES
    ('steve@gmail.com', 'password123', 'Steve John', 'CEO', '0416122357'),
    ('bob@yahoo.com', 'wordpass', 'Bob James', 'Order Processing Manager', '0423571612'),
    ('jan@gmail.com', 'wordpass123', 'Jan Smith', 'General Manager', '0457162318'),
    ('millyyahoo.com', 'pass1', 'Milly Rock', 'Order Processing Manager', '0412345891'),
    ('james@yahoo.com', 'pass2', 'James Tedesco', 'Operations Manager', '0412345892'),
    ('billy@yahoo.com', 'pass3', 'Billy Ray', 'Marketing Manager', '0412345893'),
    ('pop@yahoo.com', 'pass4', 'Pop Smoke', 'HR Manager', '0412345894'),
    ('tj@yahoo.com', 'pass5', 'Tj Sharvin', 'Customer Service Representative', '0412345895'),
    ('shair@yahoo.com', 'pass6', 'Shair Kumar', 'Customer Service Representative', '0412343895'),
    ('subrat@yahoo.com', 'pass7', 'Subrat Panthee', 'Customer Service Representative', '0412445891'),
    ('maddy@yahoo.com', 'pass8', 'Maddy White', 'Customer Service Representative', '0412345532'),
    ('corey@yahoo.com', 'pass9', 'Corey Dier', 'Customer Service Representative', '0412345655'),
    ('josh@yahoo.com', 'pass10', 'Josh Walker', 'Cyber Security Architect', '0412345222'),
    ('samir@yahoo.com', 'pass11', 'Samir Singh', 'Cyber Security Architect', '0412344333'),
    ('thomas@yahoo.com', 'pass12', 'Thomas Fiorenza', 'Logistics Manager', '0412345123');
