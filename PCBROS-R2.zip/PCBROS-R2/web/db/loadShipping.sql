INSERT INTO IOTBAYUSER.SHIPPING (STREET, SUBURB, STATE, POSTCODE, METHOD, DATE) 
VALUES 
    ('4 Gross Street', 'Carington', 'NSW','2221','expressDelivery','01-09-1999' ),
    ('2 Nottingham Crescentt', 'Cooma', 'NSW','3120','expressDelivery','04-04-2000' ),
    ('39 Tang Street', 'Tingalpa', 'QLD','2421','expressDelivery','03-13-1988'),
    ('2 Bitten Close', 'Crestmead', 'WA','2232','expressDelivery','12-24-1999'),
    ('3 Wiyand Close', 'Kunda Park', 'NT','2322','expressDelivery','11-00-2000' ),
    ('5 Clevland Road', 'North Mead', 'QLD','2712','expressDelivery','24-12-1122'),
    ('87 Pink Place', 'Farin Height', 'QLD','4212','expressDelivery','22-11-2233' ),
    ('90 Booga road', 'Warringah', 'QLD','2531','expressDelivery','10-68-2888'),
    ('69 Chickfila Plains', 'Minto', 'QLD', '2253','expressDelivery','12-12-2012'),
    ('89 Bagdad Lane', 'Casula', 'NSW', '2572','expressDelivery', '18-11-1999');

