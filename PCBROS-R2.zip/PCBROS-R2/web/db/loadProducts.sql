/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Ethan
 * Created: Jun 8, 2020
 */
INSERT INTO IOTBAYUSER.PRODUCTS (PRODUCTNAME, DEVICETYPE, UNITPRICE, QUANTITY)
VALUES
    ('Laptop', 'Computer', '500', '20'),
    ('Desktop PC', 'Computer', '1000', '10'),
    ('Keyboard', 'Peripherals', '50', '50'),
    ('Microphone', 'Audio', '20', '100'),
    ('Headphones', 'Audio', '30', '100'),
    ('Webcam', 'Video', '30', '100'),
    ('Xbox One', 'Gaming Console', '350', '50'),
    ('Playstation 4', 'Gaming Console', '350', '50'),
    ('DSLR Camera', 'Cameras', '900', '10'),
    ('50 Inch TV', 'Televisions', '500', '15'),
    ('70 Inch TV', 'Televisions', '800', '10'),
    ('Colour Printer', 'Printer', '150', '50');

