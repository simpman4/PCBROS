IoTBay Web Application
----------------------
This project is required to be opened in NetBeans IDE 8.2. Once opened you will need to create a local database with the
following information:
	Name: iotbaydb
	Username: iotbayuser
	Password: admin

Once the database has been created, you will need to run each of the sql files in the 'db' folder with a connection to the 
'iotbaydb' database in order to create tables and load data.

Once all the tables have been created and example data has been inputted, the web application is ready to run! :).

Note: The username and password to login as admin is:
	Username: iotbayadmin
	Password: password123